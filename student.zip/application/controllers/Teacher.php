
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class teacher extends CI_Controller {

public function __construct()
{
    parent::__construct();
    
    $this->load->model('Teacher_model');
    
}

    public function index()
    {
        $this->load->view('teacher_login');
    }

    public function registerForm(){
        
        $this->load->view('teacher_register');
        
    }

    public function insertTeacher(){
     
        if($this->input->post('register')){
            
            $name=$this->input->post('name');
            $username=$this->input->post('username');
            $number=$this->input->post('number');
            $email=$this->input->post('email');
            $password=md5($this->input->post('password'));

            $data=array('name'=>$name,'username'=>$username,
                        'number'=>$number,'email'=>$email,
                    'password'=>$password);

            $this->Teacher_model->teacherData($data);
            
            redirect('Teacher','refresh');
            
        }
    }

    public function checklogin(){
        if($this->input->post("login")){
            $username=$this->input->post('username');
            $password=md5($this->input->post('password'));

            $data=array('username'=>$username,'password'=>$password);
            
            $info=$this->db->get_where('teacher',array('username'=>$data['username']));
            
            foreach($info->result() as $row){

                if($data['username']==$row->username && $data['password']==$row->password){

                $_SESSION['username']=$data['username'];
                $_SESSION['password']=$data['password'];
                $_SESSION['id']=$row->id;
                
                redirect('dashboard','refresh');
                
                
            }else{
                echo "<script>alert('Invalid Username and Password');</script>";
                redirect('Teacher','refresh');
                
            }
        }
        }
    }

}

/* End of file Controllername.php */

?>