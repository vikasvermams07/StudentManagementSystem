
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class dashboard extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        
        $this->load->model('Student_model');
        
    }
    

    public function index()
    {
        
        $this->load->view('dash/home');
        
    }

    public function adduserform(){
        
        $this->load->view('dash/add_student');
        
    }

    public function viewStudent(){
        
        $this->load->view('dash/view_students');
        
    }

    public function studentInfo($id){

        if($this->input->post('add')){

            $s_name=$this->input->post('s_name');
            $s_email=$this->input->post('s_email');
            $s_number=$this->input->post('s_number');
            $s_address=$this->input->post('s_address');

            $data=array('t_id'=>$id,'s_name'=>$s_name,'s_email'=>$s_email,
                        's_number'=>$s_number,'s_address'=>$s_address);
            $this->Student_model->studentsDetails($data);
            $this->load->view('dash/view_students');
        }
    }

    public function updateStudent(){
        $this->load->view('dash/edit_view');
    }

    public function updateStudentInfo($id){

        if($this->input->post('update')){

            $s_name=$this->input->post('s_name');
            $s_email=$this->input->post('s_email');
            $s_number=$this->input->post('s_number');
            $s_address=$this->input->post('s_address');

            $data=array('s_name'=>$s_name,'s_email'=>$s_email,
                        's_number'=>$s_number,'s_address'=>$s_address);
            
            $this->db->where('id',$id);
            
            $this->db->update('student', $data);
            $this->load->view('dash/view_students');
        }
    }


    public function deleteStudent($stid){

        
        $this->db->where('id', $stid);
        
        $this->db->delete('student');

        $this->load->view('dash/view_students');
    
    }

    public function logout(){
        
        $this->load->view('dash/logout');
        
    }

}



?>