

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Login</title>
    <?php 
    $this->load->view('bootstrap');
    ?>
</head>
<body>
    <div class="container" style="padding:20px">
    <div class="panel panel-default">
    <div class="panel-heading">Login</div>
    <div style="padding:20px">
    <form action="<?=base_url()?>Teacher/checklogin" method="post" class="form-group">
    <div class="form-group">
    <label>Username</label>
    <input type="text" name="username" class="form-control" placeholder="Enter Username" required>
    </div>
    <div class="form-group">
    <label>Password</label>
    <input type="password" name="password" class="form-control" placeholder="Enter Password" required>
    </div>
    <div class="form-group">
    <button type="submit" name="login" value="login" class="btn btn-success">LogIn</button>
    <a href="<?=base_url()?>Teacher/registerForm" class="btn btn-warning">Register</a>
    </div>
    </form>
    </div>
    </div>
    </div>
</body>
</html>