<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Register</title>
    <?php 
    $this->load->view('bootstrap');
    ?>
</head>
<body>
    <div class="container" style="padding:20px">
    <div class="panel panel-default">
    <div class="panel-heading">Register</div>
    <div class="panel-body" style="padding:20px">
    <form action="<?=base_url()?>Teacher/insertTeacher" method="post" >
      <div class="form-group">
        <label>Full Name</label>
        <input type="text" name='name' class="form-control"  placeholder="Enter Full Name">
      </div>
      <div class="form-group">
        <label>Username</label>
        <input type="text" name='username' class="form-control"  placeholder="Enter Username">
      </div>
      <div class="form-group">
        <label>Contact no.</label>
        <input type="text" name='number' class="form-control"  placeholder="Enter Contact Number">
      </div>
      <div class="form-group">
        <label>Email address</label>
        <input type="email" name='email' class="form-control"  placeholder="Enter Email">
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name='password' class="form-control"  placeholder="Enter Password">
      </div>
      <div class="form-group">
      <button type="submit" class="btn btn-success" name="register" value="register">Register</button>
      <a href="<?=base_url()?>Teacher" class="btn btn-warning">LogIn</a>
      </div>
    </form>
    </div>
    </div>
    </div>
</body>
</html>