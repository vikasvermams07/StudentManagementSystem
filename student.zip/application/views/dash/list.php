

<div style="width:300px;margin-left:100px;">
<ul class="list-group" >
    <div class="panel panel-default">
    <li class="list-group-item panel-heading">Student</li>
    <li class="list-group-item "><a href="<?=base_url()?>dashboard/viewStudent">View</a></li>
    <li class="list-group-item "><a href="<?=base_url()?>dashboard/adduserform">Add</a></li>
    </div>
</ul>

</div>

