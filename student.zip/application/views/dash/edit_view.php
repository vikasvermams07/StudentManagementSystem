<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
                <?php

            $this->load->view('bootstrap');

            ?>
</head>
<body>
    <?php
    
    $this->load->view('dash/navi');
    
    ?>
    <?php
    
    $this->load->view('dash/list');
    
    ?>



    <div class="container">
    <div class="panel panel-default">
    <div class="panel-heading">Edit Student Details</div>
    <div class="panel-body">
    <?php 
    
    $stid=$this->uri->segment(3);
    
    $info=$this->db->get_where('student',array('id'=>$stid));

    foreach($info->result() as $val){
    ?>
    <form action="<?=base_url()?>dashboard/updateStudentInfo/<?=$stid?>" method="post" class="form-group">
    
    <div class="form-group">
    <label>Full Name</label>
    <input type="text" name="s_name" class="form-control" value="<?=$val->s_name?>" requirerd>
    </div>

    <div class="form-group">
    <label>Email Id</label>
    <input type="email" name="s_email" class="form-control" value="<?=$val->s_email?>" requirerd>
    </div>

    <div class="form-group">
    <label>Contact Number</label>
    <input type="text" name="s_number" class="form-control" value="<?=$val->s_number?>" requirerd>
    </div>

    <div class="form-group">
    <label>Address</label>
    <textarea name="s_address" class="form-control" required><?=$val->s_address?></textarea>
    </div>

    <div class="form-group">
    <button class="btn btn-success" name="update" value="update">Update</button>
    </div>
    </form>
    <?php } ?>
    </div>
    </div>
    </div>
</body>
</html>