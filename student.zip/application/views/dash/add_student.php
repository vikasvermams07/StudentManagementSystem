<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
                <?php

            $this->load->view('bootstrap');

            ?>
</head>
<body>
    <?php
    
    $this->load->view('dash/navi');
    
    ?>
    <?php
    
    $this->load->view('dash/list');
    
    ?>

    <div class="container">
    <div class="panel panel-default">
    <div class="panel-heading">Students Details</div>
    <div class="panel-body">
    <form action="<?=base_url()?>dashboard/studentInfo/<?=$_SESSION['id']?>" method="post" class="form-group">

    <div class="form-group">
    <label>Full Name</label>
    <input type="text" class="form-control" name="s_name" placeholder="Enter Full Name" required>
    </div>

    <div class="form-group">
    <label>Mail Id</label>
    <input type="email" class="form-control" name="s_email" placeholder="Enter Mail Id" required>
    </div>

    <div class="form-group">
    <label>Contact Number</label>
    <input type="text" class="form-control" name="s_number" placeholder="Enter Number" required>
    </div>

    <div class="form-group">
    <label>Address</label>
    <textarea name="s_address" class="form-control" placeholder="Full Address" required></textarea>
    </div>

    <div class="form-group">
    <button class="btn btn-success" name="add" value="add">Add</button>
    </div>
    
    </form>
    </div>
    </div>
    </div>
</body>
</html>