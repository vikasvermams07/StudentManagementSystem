<?php
session_destroy();

redirect('Teacher','refresh');

?>