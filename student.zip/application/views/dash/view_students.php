<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
                <?php

            $this->load->view('bootstrap');

            ?>
</head>
<body>
    <?php
    
    $this->load->view('dash/navi');
    
    ?>
    <?php
    
    $this->load->view('dash/list');
    
    ?>

    <div class="container">
    <table class="table">
    <tr>
    <th>Id</th>
    <th>Name</th>
    <th>Email</th>
    <th>Number</th>
    <th>Address</th>
    <th>Added Time</th>
    <th>Edit</th>
    <th>Delete</th>
    </tr>
    <?php
    $tid=$_SESSION['id'];
    $info=$this->db->get_where('student',array('t_id'=>$tid));

    foreach($info->result() as $val){
        ?>
        <tr>
        <td><?=$val->id?></td>
        <td><?=$val->s_name?></td>
        <td><?=$val->s_email?></td>
        <td><?=$val->s_number?></td>
        <td><?=$val->s_address?></td>
        <td><?=$val->time?></td>
        <td><a href="<?=base_url()?>dashboard/updateStudent/<?=$val->id?>" class="btn btn-warning btn-xs">Edit</a></td>
        <td><a href="<?=base_url()?>dashboard/deleteStudent/<?=$val->id?>" class="btn btn-danger btn-xs">Delete</a></td>
        </tr>
        <?php
    }
    
    ?>
    </table>
    </div>
</body>
</html>