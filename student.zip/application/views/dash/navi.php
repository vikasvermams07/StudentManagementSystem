

  <nav class="navbar  navbar-dark bg-dark" style="background-color:whitesmoke">
    <a class="navbar-brand" href="#"><?=$_SESSION['username']?></a>
    <a class="navbar-brand" href="<?=base_url()?>dashboard/logout" style="float:right">LogOut</a>
  </nav>
