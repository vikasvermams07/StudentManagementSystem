
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teacher_model extends CI_Model {

    public function teacherData($data){

        
        $this->db->insert('teacher', $data);
        
    }

}



?>