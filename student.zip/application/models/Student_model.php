
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student_model extends CI_Model {

    public function studentsDetails($data){
    
    $this->db->insert('student', $data);
    
    }

}



?>